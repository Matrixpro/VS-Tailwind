<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hello</title>


    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,500,600,70,800' rel='stylesheet' type='text/css'>
    <style>
    .center-cropped {
        object-fit: none; /* Do not scale the image */
        object-position: center; /* Center the image within the element */
        height: 300px;
        width: 490px;
    }
    .navbar {
        background-color: rgba(255,255,255,0.95);
        box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.05),inset 0 -1px 0 rgba(0,0,0,0.15);
    }
    .gallery_img {
        max-height: 275px;
    }
    .card-img, .card-img-top {
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }
    .card {
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }
</style>
</head>
<body>

<nav class="navbar navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="/">
            <img src="/images/logo.png" alt="Awesome placeholder logo!" width="98" height="70">
        </a>
    </div>
</nav>

<div class="container">
<?php echo $__env->yieldContent('content'); ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH E:\dev\bdx-interview\resources\views/layout.blade.php ENDPATH**/ ?>